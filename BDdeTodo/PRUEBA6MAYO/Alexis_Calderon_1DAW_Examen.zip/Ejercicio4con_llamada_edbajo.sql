create or replace procedure PINSERTA_LIBRO (pNewLibro IN libros%rowtype)
is
fexiste boolean:=false;
begin
 fexiste:=FEXISTE_AUTOR(pIdautor);
 if (fexiste=true) then
	insert into libros values(pNewLibro.idlibro,pNewLibro.titulo,pNewLibro.numpaginas,pNewLibro.fechapub,pNewLibro.precio,pNewLibro.idautor);
 else
	dbms_output.put_line(' El autor no existe');
 end if;
 
 EXCEPTION
  when NO_DATA_FOUND then dbms_output.put_line('no existe');
  when OTHERS then dbms_output.put_line('error');
end;

--------------------------------------------------------------------
--llamada:--
set serveroutput on;
declare
newLibro libros%rowtype;
begin
newLibro.idlibro:=&id_libro;
newLibro.titulo:='&titulo';
newLibro.numpaginas:=&num_paginas;
newLibro.fechapub:=current_date();
newLibro.precio:=&precio;
newLibro.idautor:=&id_autor;
PINSERTA_LIBRO(newLibro);

EXCEPTION
when NO_DATA_FOUND THEN dbms_output.put_line('Error: '|| SQLERRM);
when OTHERS THEN dbms_output.put_line(' ERROR '||SQLERRM);

end;
