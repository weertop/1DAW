create or replace function FEXISTE_AUTOR (vidAutor autores.idautor%type)
return resultado
is
resultado boolean:=false;
fidautor autores.idautor%type;
begin
select count(*) into fidautor from AUTORES a where vidAutor = a.idautor;
if (fidautor=1) then
  resultado = true;
else
  resultado = false;
end if;
 return (resultado);
exception
 when NO_DATA_FOUND then resultado=false;
 when TOO_MANY_ROWS then resultado=false;
end;
