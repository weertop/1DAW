create or replace function FCUANTOS_LIBROS (vidAutor autores.idautor%type)
return numlibros
is
numlibros integer:=0;
cursor cursoLibro is select * from libros where vidAutor = a.idautor and a.idautor = l.idautor;
vreg libro%rowtype;
begin
select count(idlibros) into numlibros from AUTORES a, LIBROS l where vidAutor = a.idautor and a.idautor = l.idautor;
open cursoLibro;
fetch cursoLibro into vreg;
while cursoLibro%found then
loop
	dbms_output.put_line('Autor: ' || vreg.titulo || ' Numero paginas: ' || vreg.numpaginas);
	fetch cursoLibro into vreg;
end loop;
close;
-- tambien se podria enviar el SQL%ROWCOUNT como el total de libros de cada autor --
return (numlibros);
exception
 when NO_DATA_FOUND then dbms_output.put_line('no existe');
 when OTHERS then dbms_output.put_line('error');
end;

--------------------------------------------------------------------------------------------------------------
--llamada:--

set serveroutput on
declare
numAutor AUTORES.idautor%type;
numLibros integer:=0;
begin
numAutor:=&Dame_id_autor;
numLibros:=FCUANTOS_LIBROS(numAutor);
dbms_output.put_line('numero de libros: ' || numLibros);
EXCEPTION
WHEN NO_DATA_FOUND THEN dbms_output.put_line('eRROR datos no encontrados: '||SQLERRM);
end;

