create or replace procedure PBORRAR_AUTOR (vidAutor autores.idautor%type)
is
pnombre autores.nombre%type;
fexiste boolean:=false;
begin
 fexiste:=FEXISTE_AUTOR(vidAutor);
 if (fexiste=true) then
	select NOMBRE into pnombre from AUTORES where vidAutor=idautor;
	delete from AUTORES where vidAutor=idautor;
	dbms_output.put_line(' El autor '||pnombre||' fue borrado ');
 else
	dbms_output.put_line(' El autor no existe');
 end if;
end;

----------------------------------------------------------------------------
--lamada:--

set serveroutput on;
declare
VidAutor AUTORES.IDAUTOR%TYPE;
begin
VidAutor:=&Id_Autor_para_borrar;
PBORRAR_AUTOR(VidAutor);
EXCEPTION
when NO_DATA_FOUND THEN dbms_output.put_line('El autor no existe '||VidAutor || ' ' || SQLERRM);
when OTHERS THEN dbms_output.put_line(' ERROR '||SQLERRM);
end;

--Pregunta:--
-- si vemos el libros.sql que nos han dejado no tiene ningun tipo de restriccion para--
-- eliminar los libros de un autor en cascada o ponerlos a null--
-- por lo que supongo que se quedaran igual pero perderna la referencia de su idautor--