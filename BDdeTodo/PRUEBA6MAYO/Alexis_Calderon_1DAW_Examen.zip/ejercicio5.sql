create or replace trigger triggerExamen
after insert or delete or update of titulo
on libros
for each row
declare
begin
if inserting then
dbms_output.put_line('Nuevo titulo de libro insertado: ' || new.titulo);
end if;
if deleting then
dbms_output.put_line('titulo de libro borrado: ' || old.titulo);
end if;
if updating then
dbms_output.put_line('Modificacion de titulo de un libro: ' || old.titulo || ' nuevo titulo: ' || new.titulo);
end if;
end;