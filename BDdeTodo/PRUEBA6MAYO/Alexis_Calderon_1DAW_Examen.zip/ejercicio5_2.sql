create or replace trigger triggerExamen2do
before update of precio
on libros
for each row
declare
vNombre autores.nombre%type;
begin
if updating then
select a.nombre INTO vNombre FROM autores a, libros l WHERE a.idautor = l.idautor and a.nombre like ('cervantes');
dbms_output.put_line('se esta intentado modificar el precio de un libro de cervantes con precio antiguo: ' || old.precio || ' con el nuevo precio: ' || new.precio || ' pero esta prohibido');
end if;
end;