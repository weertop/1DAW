package capitulo9;

public class Vehiculo {
	private int numRuedas;
	private int velMax;
	private int peso;
	Vehiculo(int nr,int vel,int p){
		this.numRuedas=nr;
		this.velMax=vel;
		this.peso=p;
	}
	public int getnumRuedas() {
		return this.numRuedas;
	}
	public int getvelMax() {
		return this.velMax;
	}
	public int getpeso() {
		return this.peso;
	}
	public void setnumRuedas(int nuevoNum) {
		this.numRuedas=nuevoNum;
	}
	public void setvelMax(int nuevoVel) {
		this.velMax=nuevoVel;
	}
	public void setpeso(int nuevoPeso) {
		this.peso=nuevoPeso;
	}
	public void informe() {
		System.out.println("el vehiculo tiene "+this.numRuedas+
				" ruedas y su velocidad maxima es "+this.velMax+
				" km/hora y su peso es de "+this.peso+" kilos");
	}
	public boolean esIgual(Vehiculo otroVeh) {
		boolean sol=false;
		if (this.numRuedas==otroVeh.getnumRuedas() && this.velMax==otroVeh.getvelMax()
				&& this.peso==otroVeh.getpeso()) {
			sol=true;
		}
	return sol;
	}
	public void copia(Vehiculo otroVeh) {
		otroVeh.setnumRuedas(this.numRuedas);
		otroVeh.setvelMax(this.velMax);
		otroVeh.setpeso(this.peso);
	}
	public void copia2(Vehiculo otroVeh) {
		this.numRuedas=otroVeh.getnumRuedas();
		this.velMax=otroVeh.getvelMax();
		this.peso=otroVeh.getpeso();
	}
}
