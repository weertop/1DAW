package capitulo9;
import java.util.*;
public class funcionalNombres {

	public static void main(String[] args) {
		Scanner teclado=new Scanner(System.in);
		Nombres listaNombres=new Nombres(5);
		String nb;
		boolean sw=true;
		while (sw) {
			System.out.println("intro nombres y acaba con fin");
			nb=teclado.next();
			if (nb.equals("fin")) {
				break;
			}
			else {
				listaNombres.insertar(nb);
			}
		}
		listaNombres.mostarTodaLista();
	}

}
