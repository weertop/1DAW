package capitulo9;

public class testNombres {

	public static void main(String[] args) {
		int val;
		Nombres listaNombres=new Nombres(15);
		listaNombres.insertar("pepe");
		listaNombres.insertar("maria");
		listaNombres.insertar("pepe");
		listaNombres.insertar("paco");
		listaNombres.insertar("marta");
		listaNombres.insertar("jesus");
		listaNombres.insertar("ana");
		listaNombres.insertar("manul");
		listaNombres.insertar("pepe");
		listaNombres.mostarTodaLista();
		if (listaNombres.eliminar("paco")) {
			System.out.println("eliminado");
		}else {
			System.out.println("no eliminado pq no estaba");
		}
		listaNombres.mostarTodaLista();
		listaNombres.insertar("jean");
		listaNombres.mostarTodaLista();
		if (listaNombres.eliminar("pepe")) {
			System.out.println("eliminado");
		}else {
			System.out.println("no eliminado pq no estaba");
		}
		if (listaNombres.eliminar("jean")) {
			System.out.println("eliminado");
		}else {
			System.out.println("no eliminado pq no estaba");
		}
		listaNombres.mostarTodaLista();
		if (listaNombres.eliminar("carlos")) {
			System.out.println("eliminado");
		}else {
			System.out.println("no eliminado pq no estaba");
		}
		listaNombres.mostarTodaLista();
	}

}
