package capitulo9;

public class testVehiculo {

	public static void main(String[] args) {
		Vehiculo v1=new Vehiculo(2,180,500);
		Vehiculo v2=new Vehiculo(4,200,1000);
		Vehiculo v3=new Vehiculo(3,50,400);
		v1.informe();
		System.out.println("ruedas : "+v1.getnumRuedas());
		v1.setvelMax(200);
		v1.informe();
		if (v1.esIgual(v2)) {
			System.out.println("son iguales");
		}else {
			System.out.println("son diferentes");
		}
		v1.setnumRuedas(4);
		v2.setpeso(500);
		if (v1.esIgual(v2)) {
			System.out.println("son iguales");
		}else {
			System.out.println("son diferentes");
		}
		v1.copia2(v3);
		v1.informe();
		v1.copia(v2);
		v2.informe();
	}

}
