echo "introduzca un número"
read A

if [ $A -gt 10 ]; then
	echo "demasiado grande"
else
	echo "normal"
fi
