#!/bin/bash

groups $1 | cat >subgrupo
echo $HOME | cat >>subgrupo
